create procedure proc_obtenerODA(IN objetoAprendizaje varchar(500))
select nombre_objetoaprendizaje, descripcion_objetoaprendizaje,enlace_objetoaprendizaje
	from objetoaprendizaje
	where nombre_objetoaprendizaje like concat('%',objetoAprendizaje,'%');

